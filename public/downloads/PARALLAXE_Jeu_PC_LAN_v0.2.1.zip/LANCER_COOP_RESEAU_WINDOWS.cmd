@echo off
cd /d "%~dp0"
node scripts/start-local.mjs --lan
pause
